//Run Express code to start the server
var express = require('express');
var app = express();
//The port the server will run on
var server = app.listen(8810);
var io = require('socket.io').listen(server);
//Sets IP as string TempIP, will be changed in code below
var myip = "tempIP";

//Get server request and communicate with the html index
app.get('/', function(req, res) {
	res.sendFile(__dirname + '/index.html');
	
	//retrieves ip address
	var ip = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
		if (ip.substr(0, 7) == "::ffff:") {
		  ip = ip.substr(7)
		  
}
myip = ip.toString();
	
});
app.use('/client', express.static(__dirname + '/client'));

//If started sucessfully, output text in console
console.log("Server started.");

//End of express code
//-------------------------------------------------------------------------------


//Recieve connection information from players
var SOCKET_LIST = {};
//Used to hold individual players IP Address (To see who connects / leaves in console)
var IP_LIST = {};

var PLAYERNAMES = {};

//Initilize function
var Entity = function(){
	var self = {
		//Sets player start position
		x:-1000,
		y:-1000,
		spdX:0,
		spdY:0,
		id:"",
	}
	//Updates player position
	self.update = function(){
		self.updatePosition();
	}
	//Applies movement
	self.updatePosition = function(){
		self.x += self.spdX;
		self.y += self.spdY;
	}
	
	self.getDistance = function(pt)
	{
		return Math.sqrt(Math.pow(self.x - pt.x,2) + Math.pow(self.y - pt.y,2));
	}
	
	return self;
}

var Player = function(id)
{
	var colors = ["Red", "RoyalBlue", "Green", "Gold", "DarkViolet", "Orange", "Pink", "Teal", "Fuchsia", "LawnGreen"];
	var self = Entity();
		self.id = id;
		self.name = "Blaster :D"
		//Assigns the player displayed as a random number
		self.number = "" + Math.floor(10 * Math.random());
		//Checks if a button is down
		self.pressingRight = false;
		self.pressingLeft = false;
		self.pressingUp = false;
		self.pressingDown = false;
		self.pressingAttack = false;
		self.maxSpd = 10;
		self.mouseX = 0;
		self.mouseY = 0;
		self.shootTimer = 0;
		self.Color = colors[Math.floor(Math.random() * colors.length)];
		self.hp = 20;
		self.hpMax = 20;
		self.score = 0;
		self.attackspeed = 20;
		self.attackdmg = 20;
		self.exp = 0;
		self.shootcount = 0;
		
		var super_update = self.update;
		self.update = function(){
			self.updateSpd();
			super_update();
			
			if(self.pressingAttack)
			{
				self.shootTimer+= self.attackspeed / 10;
				if(self.shootTimer >= 10)
				{
					self.shootBullet();
					self.shootTimer = 0;
				}
			}
		}
		
		
		
		
		
		
		self.shootBullet = function(){
			
			var angle = Math.atan2((-self.y + self.mouseY-8),(-self.x + self.mouseX-8)) / Math.PI * 180;

				var b = Bullet(self.id, angle, self.Color);
				b.x = self.x;
				b.y = self.y;
		}
		
		
		self.updateSpd = function(){
			if(self.pressingRight)
			self.x += self.maxSpd;
			if(self.pressingLeft)
				self.x -= self.maxSpd;
			if(self.pressingUp)
				self.y -= self.maxSpd;
			if(self.pressingDown)
				self.y += self.maxSpd;
		}
		
		
		
		
		self.getInitPack = function()
		{
			return{
				id:self.id,
				x:self.x,
				y:self.y,  
				number:self.number,
				playername:self.name,
				playercolor:self.Color,
				hp:self.hp,
				hpMax:self.hpMax,
				score:self.score,
				exp:self.exp,
			};
		}
		self.getUpdatePack = function()
		{
			return{
				x:self.x,
				y:self.y,
				id:self.id,
				playername:self.name,
				playercolor:self.Color,
				hp:self.hp,
				score:self.score,
				exp:self.exp,
			};
		}
		
		Player.list[id] = self;
		
		initPack.player.push(self.getInitPack());
		return self;
}
	
Player.list = {};

Player.onConnect = function(socket)
{
	var player = Player(socket.id);
	
	//Checks movement based on keys pressed
	socket.on('keyPress', function(data){
		if(data.inputID === 'left')
			player.pressingLeft = data.state;
		if(data.inputID === 'right')
			player.pressingRight = data.state;
		if(data.inputID === 'up')
			player.pressingUp = data.state;
		if(data.inputID === 'down')
			player.pressingDown = data.state;
		if(data.inputID === 'attack')
			player.pressingAttack = data.state;
		if(data.inputID === 'mouseX')
			player.mouseX = data.state;
		if(data.inputID === 'mouseY')
			player.mouseY = data.state;
		
		if(data.inputID === '1')
		{
			if(player.exp > 0 && player.maxSpd > 1)
			{
				player.attackspeed += 1;
				player.maxSpd -= 1;
				player.exp -= 1;
			}
		}
		if(data.inputID === '2')
		{
			if(player.exp > 0)
			{
				if(player.hp < player.hpMax)
				{
					player.hp += 4;
					player.exp -= 1;
					if(player.hp > player.hpMax)
					{
						player.hp = player.hpMax;
					}
				}
			}
		}
		if(data.inputID === '3')
		{
			if(player.exp > 0 && player.hpMax > 1)
			{
				player.attackdmg += 1;
				player.hpMax -= 1;
				player.exp -= 1;
				if(player.hp > 1)
				{
					player.hp -= 1;
				}
			}
		}
		if(data.inputID === '4' && player.attackspeed > 1)
		{
			if(player.exp > 0)
			{
				player.maxSpd += 1;
				player.attackspeed -= 1;
				player.exp -= 1;
			}
		}
		if(data.inputID === '5' && player.attackdmg > 1)
		{
			if(player.exp > 0)
			{
				player.attackdmg -= 1;
				player.hpMax += 1;
				player.exp -= 1;
				if(player.hp < 20)
				{
					player.hp += 1;
				}
			}
		}
	});
	
	
	

	
	socket.emit('init',{
		selfId: socket.id,
		player:Player.getAllInitPack(),
		bullet:Bullet.getAllInitPack(),
	})
}

Player.getAllInitPack = function()
{
	var players = [];
	for(var i in Player.list)
		players.push(Player.list[i].getInitPack());
	return players;
}

Player.onDisconnect = function(socket)
{
	delete Player.list[socket.id];
	removePack.player.push(socket.id);
}

Player.update = function()
{
	var pack = [];
	for(var i in Player.list){
		var player = Player.list[i];
		player.update();
		pack.push(player.getUpdatePack());
	}
	return pack;
}

var Bullet = function(parent, angle, color)
{
	var self = Entity();
	self.id = Math.random();
	self.spdX = Math.cos(angle/180*Math.PI) * 15;
	self.spdY = Math.sin(angle/180*Math.PI) * 15;
	self.parent = parent;
	self.timer = 0;
	self.toRemove = false;
	self.Color = color;
	var super_update = self.update;
	self.update = function()
	{
		if(self.timer++ > 100)
			self.toRemove = true;
		super_update();
		
		for(var i in Player.list)
		{
			var p = Player.list[i];
			if(self.getDistance(p) < 32 && self.parent !== p.id)
			{
				var shooter = Player.list[self.parent];
				
				if(shooter)
					p.hp -= shooter.attackdmg / 20;
				if(p.hp <= 0)
				{
					
					if(shooter)
					{
						shooter.score += 1;
						shooter.exp += 1
					}
					if(p.hp <= 0)
					{
						shooter.score += Math.floor(p.score / 1.5);
						shooter.exp += Math.floor(p.score / 1.5);
						p.score = 0;
						p.attackspeed = 10;
						p.attackdmg = 20;
						p.maxSpd = 20;
						p.hpMax = 20;
						p.hp = p.hpMax;
						p.exp = 0;
						p.x = Math.random() * 1200;
						p.y = Math.random() * 800;
					}
					
					//handle collision. ex: hp--;
					
				}
				self.toRemove = true;
			}
		}
		
	}
	
	self.getInitPack = function()
	{
		return{
			id:self.id,
			x:self.x,
			y:self.y,
			bulletcolor:self.Color,
			bulletparent:self.parent,
		};
	}
	self.getUpdatePack = function()
	{
		return{
			id:self.id,
			x:self.x,
			y:self.y,
			bulletcolor:self.Color,
		};
	}
	
	Bullet.list[self.id] = self;
	initPack.bullet.push(self.getInitPack());
	return self;
}
Bullet.list = {};


Bullet.update = function()
{
	var pack = [];
	for(var i in Bullet.list){
		var bullet = Bullet.list[i];
		bullet.update();
		
		if(bullet.toRemove)
		{
			delete Bullet.list[i];
			removePack.bullet.push(bullet.id);
		}
		else
		pack.push(bullet.getUpdatePack());
	}
	return pack;
}

Bullet.getAllInitPack = function()
{
	var bullets = [];
	for(var i in Bullet.list)
		bullets.push(Bullet.list[i].getInitPack());
	return bullets;
}

io.sockets.on('connection', function(socket){
	//Assigns individual ID at random
	socket.id = Math.random();
	SOCKET_LIST[socket.id] = socket;
	IP_LIST[socket.id] = myip;
	
	Player.onConnect(socket);
	//Display when a player connects to the server
	console.log('Socket connect ' + IP_LIST[socket.id]);
	
	//Display when a player leaves the server, and delete their player info
	socket.on('disconnect', function(){
		console.log('Socket disconnect ' + IP_LIST[socket.id]);
		delete SOCKET_LIST[socket.id];
		Player.onDisconnect(socket);
		delete IP_LIST[socket.id];
	});
	
	socket.on('sendMsgToServer', function(data){
		for(var i in SOCKET_LIST){
			SOCKET_LIST[i].emit('addToChat',PLAYERNAMES[socket.id] + ': ' + data);
		}
	});
	
	socket.on('sendNameToServer', function(data){
		
		PLAYERNAMES[socket.id] = data;
		for(var i in Player.list){
			if(Player.list[i].id == socket.id)
			{
				Player.list[i].name = data;
				Player.list[i].x = Math.random() * 1200;
				Player.list[i].y = Math.random() * 800;
				if(Player.list[i].name == "Admin")
				{
					Player.list[i].exp = 100;
					Player.list[i].score = 100;
					Player.list[i].attackdmg = 10000;
				}
			}
			
		}
	});
});

var initPack = {player:[], bullet:[]};
var removePack = {player:[], bullet:[]};




//Frequency of updates on screen / information sent back and forth
setInterval(function(){
	
	var pack = {
		player:Player.update(),
		bullet:Bullet.update(),
	}

	
	for(var i in SOCKET_LIST){
		var socket = SOCKET_LIST[i];
		socket.emit('init', initPack);
		socket.emit('update',pack);
		socket.emit('remove', removePack);
	}
	
	initPack.player = [];
	initPack.bullet = [];
	removePack.player = [];
	removePack.bullet = [];
	
}, 1000/50);