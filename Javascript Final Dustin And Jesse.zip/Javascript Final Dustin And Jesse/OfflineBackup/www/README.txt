Run Javascript Server to run the server

This folder must be on the desktop

Run the website in your browser with localhost:8810

I'm using NotePad++ to code